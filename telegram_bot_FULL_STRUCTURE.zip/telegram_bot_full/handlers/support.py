
from aiogram import Router, F
from aiogram.types import Message

router = Router()

@router.message(F.text == "📞 Поддержка")
async def support(message: Message):
    await message.answer("Связь с поддержкой: @your_support")
