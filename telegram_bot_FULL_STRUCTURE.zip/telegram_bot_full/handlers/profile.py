
from aiogram import Router, F
from aiogram.types import Message
from database import get_user

router = Router()

@router.message(F.text == "👤 Профиль")
async def profile(message: Message):
    user = await get_user(message.from_user.id)
    if not user:
        return
    text = f"ID: {user[0]}\nБаланс: {user[2]} 💰\nPremium: {'Да' if user[3] else 'Нет'}"
    await message.answer(text)
