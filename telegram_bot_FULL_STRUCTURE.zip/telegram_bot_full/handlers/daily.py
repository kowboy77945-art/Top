
from aiogram import Router, F
from aiogram.types import Message
from config import DAILY_REWARD
from database import update_balance

router = Router()

@router.message(F.text == "🎁 Бонус")
async def daily(message: Message):
    await update_balance(message.from_user.id, DAILY_REWARD)
    await message.answer(f"🎉 Ты получил {DAILY_REWARD}")
