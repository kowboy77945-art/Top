
from aiogram import Router, F
from aiogram.types import Message
from config import PREMIUM_PRICE
from database import get_user, update_balance, set_premium

router = Router()

@router.message(F.text == "💰 Магазин")
async def shop(message: Message):
    await message.answer(f"Premium стоит {PREMIUM_PRICE}. Напиши: купить")

@router.message(F.text.lower() == "купить")
async def buy_premium(message: Message):
    user = await get_user(message.from_user.id)
    if user[2] >= PREMIUM_PRICE:
        await update_balance(message.from_user.id, -PREMIUM_PRICE)
        await set_premium(message.from_user.id, 1)
        await message.answer("💎 Premium активирован!")
    else:
        await message.answer("❌ Недостаточно средств")
