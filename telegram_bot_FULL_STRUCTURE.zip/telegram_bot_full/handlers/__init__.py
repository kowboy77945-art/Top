
from .start import router as start_router
from .profile import router as profile_router
from .shop import router as shop_router
from .games import router as games_router
from .promo import router as promo_router
from .referral import router as referral_router
from .daily import router as daily_router
from .settings import router as settings_router
from .admin import router as admin_router
from .support import router as support_router

def register_handlers(dp):
    dp.include_router(start_router)
    dp.include_router(profile_router)
    dp.include_router(shop_router)
    dp.include_router(games_router)
    dp.include_router(promo_router)
    dp.include_router(referral_router)
    dp.include_router(daily_router)
    dp.include_router(settings_router)
    dp.include_router(admin_router)
    dp.include_router(support_router)
