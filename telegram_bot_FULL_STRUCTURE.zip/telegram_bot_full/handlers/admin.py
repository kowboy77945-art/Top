
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from config import ADMIN_IDS
from database import update_balance, set_ban, set_premium

router = Router()

def is_admin(user_id):
    return user_id in ADMIN_IDS

@router.message(Command("admin"))
async def admin_panel(message: Message):
    if not is_admin(message.from_user.id):
        return
    await message.answer("ADMIN PANEL\n/give id amount\n/ban id\n/unban id")

@router.message(Command("give"))
async def give(message: Message):
    if not is_admin(message.from_user.id):
        return
    _, uid, amount = message.text.split()
    await update_balance(int(uid), int(amount))
    await message.answer("Выдано")

@router.message(Command("ban"))
async def ban(message: Message):
    if not is_admin(message.from_user.id):
        return
    uid = int(message.text.split()[1])
    await set_ban(uid, 1)
    await message.answer("Забанен")

@router.message(Command("unban"))
async def unban(message: Message):
    if not is_admin(message.from_user.id):
        return
    uid = int(message.text.split()[1])
    await set_ban(uid, 0)
    await message.answer("Разбанен")
