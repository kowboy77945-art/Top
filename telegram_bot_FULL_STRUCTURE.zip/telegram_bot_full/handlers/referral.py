
from aiogram import Router, F
from aiogram.types import Message
from config import REFERRAL_REWARD
from database import update_balance

router = Router()

@router.message(F.text == "👥 Реферал")
async def referral(message: Message):
    link = f"https://t.me/YOUR_BOT?start={message.from_user.id}"
    await message.answer(f"Твоя ссылка: {link}")
