
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from keyboards import main_menu
from database import add_user

router = Router()

@router.message(Command("start"))
async def start_cmd(message: Message):
    await add_user(message.from_user.id, message.from_user.username)
    await message.answer("🔥 Добро пожаловать в FULL BOT!", reply_markup=main_menu())
