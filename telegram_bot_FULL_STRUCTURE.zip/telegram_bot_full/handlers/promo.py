
from aiogram import Router, F
from aiogram.types import Message
from database import update_balance

router = Router()

@router.message(F.text.startswith("/promo"))
async def promo(message: Message):
    await update_balance(message.from_user.id, 500)
    await message.answer("🎁 Промокод активирован +500")
