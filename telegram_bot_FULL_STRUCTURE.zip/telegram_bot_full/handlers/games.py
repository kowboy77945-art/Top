
from aiogram import Router, F
from aiogram.types import Message
from database import update_balance
import random

router = Router()

@router.message(F.text == "🎮 Игры")
async def games(message: Message):
    await message.answer("Напиши: dice")

@router.message(F.text.lower() == "dice")
async def dice_game(message: Message):
    roll = random.randint(1, 6)
    if roll >= 4:
        await update_balance(message.from_user.id, 500)
        await message.answer(f"🎲 {roll} Победа +500")
    else:
        await update_balance(message.from_user.id, -200)
        await message.answer(f"🎲 {roll} Проигрыш -200")
