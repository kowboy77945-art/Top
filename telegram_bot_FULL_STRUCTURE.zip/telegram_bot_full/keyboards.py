
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def main_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="👤 Профиль"), KeyboardButton(text="🎮 Игры")],
            [KeyboardButton(text="💰 Магазин"), KeyboardButton(text="🎁 Бонус")],
            [KeyboardButton(text="🎟 Промокод"), KeyboardButton(text="👥 Реферал")],
            [KeyboardButton(text="⚙ Настройки"), KeyboardButton(text="📞 Поддержка")]
        ],
        resize_keyboard=True
    )
