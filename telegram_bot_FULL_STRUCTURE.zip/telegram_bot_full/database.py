
import aiosqlite
import datetime

DB_NAME = "bot.db"

async def init_db():
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
        CREATE TABLE IF NOT EXISTS users(
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            balance INTEGER DEFAULT 1000,
            premium INTEGER DEFAULT 0,
            banned INTEGER DEFAULT 0,
            referral_from INTEGER,
            daily_last TEXT
        )
        """)
        await db.execute("""
        CREATE TABLE IF NOT EXISTS promos(
            code TEXT PRIMARY KEY,
            reward INTEGER,
            uses INTEGER DEFAULT 0,
            max_uses INTEGER
        )
        """)
        await db.commit()

async def add_user(user_id, username, referral=None):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users (user_id, username, referral_from) VALUES (?, ?, ?)",
            (user_id, username, referral)
        )
        await db.commit()

async def get_user(user_id):
    async with aiosqlite.connect(DB_NAME) as db:
        cur = await db.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
        return await cur.fetchone()

async def update_balance(user_id, amount):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (amount, user_id))
        await db.commit()

async def set_premium(user_id, value):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("UPDATE users SET premium=? WHERE user_id=?", (value, user_id))
        await db.commit()

async def set_ban(user_id, value):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("UPDATE users SET banned=? WHERE user_id=?", (value, user_id))
        await db.commit()
